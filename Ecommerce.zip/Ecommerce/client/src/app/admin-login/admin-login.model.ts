export class AdminLoginModel{
    constructor(
        
        public email: string,
        public password: string,
        ){}
}