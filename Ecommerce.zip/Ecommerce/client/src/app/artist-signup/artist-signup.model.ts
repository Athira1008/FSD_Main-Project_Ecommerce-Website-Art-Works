export class ArtistSignupModel{
    constructor(
        
        public email: string,
        public password: string,
        ){}
}