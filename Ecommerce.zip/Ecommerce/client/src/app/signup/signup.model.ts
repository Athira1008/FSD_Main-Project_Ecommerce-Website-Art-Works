export class SignupModel{
    constructor(
        
        public email: string,
        public password: string,
        ){}
}