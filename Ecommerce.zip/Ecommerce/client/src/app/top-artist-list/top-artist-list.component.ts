import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-top-artist-list',
  templateUrl: './top-artist-list.component.html',
  styleUrls: ['./top-artist-list.component.css']
})
export class TopArtistListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
