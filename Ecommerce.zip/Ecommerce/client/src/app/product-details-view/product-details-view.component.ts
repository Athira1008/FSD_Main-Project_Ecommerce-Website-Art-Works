import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-details-view',
  templateUrl: './product-details-view.component.html',
  styleUrls: ['./product-details-view.component.css']
})
export class ProductDetailsViewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
