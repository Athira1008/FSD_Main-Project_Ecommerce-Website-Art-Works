import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-art-work-top-category-list',
  templateUrl: './art-work-top-category-list.component.html',
  styleUrls: ['./art-work-top-category-list.component.css']
})
export class ArtWorkTopCategoryListComponent implements OnInit {
  
  constructor() { }

  ngOnInit(): void {
  }

}
